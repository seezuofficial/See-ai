package com.see.assistant.receiver

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import com.see.assistant.utils.Logger

/**
 * SEEDeviceAdminReceiver - Device admin permission ke liye
 * 
 * Isse screen lock karne ki permission milti hai
 */
class SEEDeviceAdminReceiver : DeviceAdminReceiver() {
    
    private val TAG = "SEEDeviceAdminReceiver"
    
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Logger.i(TAG, "✅ Device admin enabled")
    }
    
    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Logger.w(TAG, "⚠️ Device admin disabled")
    }
    
    override fun onPasswordChanged(context: Context, intent: Intent, userHandle: android.os.UserHandle) {
        super.onPasswordChanged(context, intent, userHandle)
        Logger.d(TAG, "Password changed")
    }
    
    override fun onPasswordFailed(context: Context, intent: Intent, userHandle: android.os.UserHandle) {
        super.onPasswordFailed(context, intent, userHandle)
        Logger.d(TAG, "Password failed")
    }
    
    override fun onPasswordSucceeded(context: Context, intent: Intent, userHandle: android.os.UserHandle) {
        super.onPasswordSucceeded(context, intent, userHandle)
        Logger.d(TAG, "Password succeeded")
    }
}
