package com.see.assistant.modules

import android.content.Context
import androidx.room.*
import com.see.assistant.utils.Logger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.Date

/**
 * MemoryManager - User ki memory aur preferences store karta hai
 * 
 * Room Database use karta hai for:
 * - Conversation history
 * - Frequently used commands
 * - User behavior patterns
 * - Custom shortcuts
 */
@Database(
    entities = [
        Conversation::class,
        FrequentCommand::class,
        UserPattern::class,
        CustomShortcut::class,
        ContactAlias::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class SEEDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun frequentCommandDao(): FrequentCommandDao
    abstract fun userPatternDao(): UserPatternDao
    abstract fun customShortcutDao(): CustomShortcutDao
    abstract fun contactAliasDao(): ContactAliasDao
}

class Converters {
    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }
}

// ==================== ENTITIES ====================

@Entity(tableName = "conversations")
data class Conversation(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userMessage: String,
    val assistantResponse: String,
    val timestamp: Date = Date(),
    val commandType: String? = null,
    val wasSuccessful: Boolean = true
)

@Entity(tableName = "frequent_commands")
data class FrequentCommand(
    @PrimaryKey
    val command: String,
    val count: Int = 1,
    val lastUsed: Date = Date(),
    val averageExecutionTime: Long = 0
)

@Entity(tableName = "user_patterns")
data class UserPattern(
    @PrimaryKey
    val patternType: String,
    val patternData: String,
    val confidence: Float = 0.5f,
    val lastUpdated: Date = Date()
)

@Entity(tableName = "custom_shortcuts")
data class CustomShortcut(
    @PrimaryKey
    val triggerPhrase: String,
    val action: String,
    val actionData: String? = null,
    val createdAt: Date = Date()
)

@Entity(tableName = "contact_aliases")
data class ContactAlias(
    @PrimaryKey
    val alias: String,
    val contactName: String,
    val phoneNumber: String? = null
)

// ==================== DAOs ====================

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentConversations(limit: Int = 50): Flow<List<Conversation>>
    
    @Query("SELECT * FROM conversations WHERE commandType = :type ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getConversationsByType(type: String, limit: Int = 20): List<Conversation>
    
    @Insert
    suspend fun insert(conversation: Conversation): Long
    
    @Query("DELETE FROM conversations WHERE timestamp < :beforeDate")
    suspend fun deleteOldConversations(beforeDate: Date)
    
    @Query("SELECT COUNT(*) FROM conversations")
    suspend fun getConversationCount(): Int
}

@Dao
interface FrequentCommandDao {
    @Query("SELECT * FROM frequent_commands ORDER BY count DESC LIMIT :limit")
    fun getMostFrequent(limit: Int = 10): Flow<List<FrequentCommand>>
    
    @Query("SELECT * FROM frequent_commands WHERE command = :command LIMIT 1")
    suspend fun getCommand(command: String): FrequentCommand?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(command: FrequentCommand)
    
    @Query("UPDATE frequent_commands SET count = count + 1, lastUsed = :date WHERE command = :command")
    suspend fun incrementCount(command: String, date: Date = Date())
}

@Dao
interface UserPatternDao {
    @Query("SELECT * FROM user_patterns WHERE patternType = :type")
    suspend fun getPattern(type: String): UserPattern?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePattern(pattern: UserPattern)
    
    @Query("SELECT * FROM user_patterns ORDER BY confidence DESC")
    fun getAllPatterns(): Flow<List<UserPattern>>
}

@Dao
interface CustomShortcutDao {
    @Query("SELECT * FROM custom_shortcuts")
    fun getAllShortcuts(): Flow<List<CustomShortcut>>
    
    @Query("SELECT * FROM custom_shortcuts WHERE triggerPhrase = :phrase LIMIT 1")
    suspend fun getShortcut(phrase: String): CustomShortcut?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveShortcut(shortcut: CustomShortcut)
    
    @Delete
    suspend fun deleteShortcut(shortcut: CustomShortcut)
}

@Dao
interface ContactAliasDao {
    @Query("SELECT * FROM contact_aliases WHERE alias = :alias LIMIT 1")
    suspend fun getContactByAlias(alias: String): ContactAlias?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAlias(contactAlias: ContactAlias)
    
    @Query("SELECT * FROM contact_aliases")
    fun getAllAliases(): Flow<List<ContactAlias>>
}

// ==================== MEMORY MANAGER ====================

class MemoryManager(private val context: Context) {
    
    private val TAG = "MemoryManager"
    private lateinit var database: SEEDatabase
    
    // DAOs
    private val conversationDao get() = database.conversationDao()
    private val frequentCommandDao get() = database.frequentCommandDao()
    private val userPatternDao get() = database.userPatternDao()
    private val customShortcutDao get() = database.customShortcutDao()
    private val contactAliasDao get() = database.contactAliasDao()
    
    suspend fun initialize() {
        Logger.d(TAG, "🧠 Initializing MemoryManager")
        database = Room.databaseBuilder(
            context.applicationContext,
            SEEDatabase::class.java,
            "see_memory.db"
        )
        .fallbackToDestructiveMigration()
        .build()
        
        // Cleanup old data
        cleanupOldData()
    }
    
    // ==================== CONVERSATIONS ====================
    
    suspend fun saveConversation(
        userMessage: String,
        assistantResponse: String,
        commandType: String? = null,
        wasSuccessful: Boolean = true
    ) {
        val conversation = Conversation(
            userMessage = userMessage,
            assistantResponse = assistantResponse,
            commandType = commandType,
            wasSuccessful = wasSuccessful
        )
        conversationDao.insert(conversation)
        Logger.d(TAG, "💬 Conversation saved: $commandType")
    }
    
    fun getRecentConversations(limit: Int = 50): Flow<List<Conversation>> {
        return conversationDao.getRecentConversations(limit)
    }
    
    // ==================== FREQUENT COMMANDS ====================
    
    suspend fun recordCommandUsage(command: String, executionTime: Long = 0) {
        val existing = frequentCommandDao.getCommand(command)
        if (existing != null) {
            frequentCommandDao.incrementCount(command)
        } else {
            frequentCommandDao.insertOrUpdate(
                FrequentCommand(command = command, averageExecutionTime = executionTime)
            )
        }
    }
    
    fun getFrequentCommands(limit: Int = 10): Flow<List<FrequentCommand>> {
        return frequentCommandDao.getMostFrequent(limit)
    }
    
    suspend fun getSuggestedCommands(): List<String> {
        return frequentCommandDao.getMostFrequent(5).first().map { it.command }
    }
    
    // ==================== USER PATTERNS ====================
    
    suspend fun savePattern(patternType: String, data: String, confidence: Float) {
        userPatternDao.savePattern(
            UserPattern(patternType = patternType, patternData = data, confidence = confidence)
        )
    }
    
    suspend fun getPattern(patternType: String): UserPattern? {
        return userPatternDao.getPattern(patternType)
    }
    
    // ==================== CUSTOM SHORTCUTS ====================
    
    suspend fun saveShortcut(triggerPhrase: String, action: String, actionData: String? = null) {
        customShortcutDao.saveShortcut(
            CustomShortcut(triggerPhrase = triggerPhrase, action = action, actionData = actionData)
        )
        Logger.d(TAG, "🔖 Shortcut saved: $triggerPhrase -> $action")
    }
    
    suspend fun getShortcut(phrase: String): CustomShortcut? {
        return customShortcutDao.getShortcut(phrase.lowercase())
    }
    
    fun getAllShortcuts(): Flow<List<CustomShortcut>> {
        return customShortcutDao.getAllShortcuts()
    }
    
    suspend fun deleteShortcut(shortcut: CustomShortcut) {
        customShortcutDao.deleteShortcut(shortcut)
    }
    
    // ==================== CONTACT ALIASES ====================
    
    suspend fun saveContactAlias(alias: String, contactName: String, phoneNumber: String? = null) {
        contactAliasDao.saveAlias(
            ContactAlias(alias = alias.lowercase(), contactName = contactName, phoneNumber = phoneNumber)
        )
    }
    
    suspend fun getContactByAlias(alias: String): ContactAlias? {
        return contactAliasDao.getContactByAlias(alias.lowercase())
    }
    
    // ==================== SMART SUGGESTIONS ====================
    
    suspend fun getSmartSuggestions(currentContext: String): List<String> {
        val suggestions = mutableListOf<String>()
        
        // Time-based suggestions
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        when (hour) {
            in 6..9 -> suggestions.add("Good morning routine")
            in 12..14 -> suggestions.add("Lunch time reminders")
            in 18..22 -> suggestions.add("Evening mode")
        }
        
        // Add frequent commands
        suggestions.addAll(getSuggestedCommands().take(3))
        
        return suggestions.distinct()
    }
    
    // ==================== CLEANUP ====================
    
    private suspend fun cleanupOldData() {
        // Delete conversations older than 30 days
        val thirtyDaysAgo = Date(System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000)
        conversationDao.deleteOldConversations(thirtyDaysAgo)
        Logger.d(TAG, "🧹 Old data cleaned up")
    }
    
    // ==================== EXPORT/IMPORT ====================
    
    suspend fun exportMemory(): Map<String, Any> {
        return mapOf(
            "conversations" to conversationDao.getRecentConversations(100).first(),
            "frequent_commands" to frequentCommandDao.getMostFrequent(50).first(),
            "shortcuts" to customShortcutDao.getAllShortcuts().first(),
            "aliases" to contactAliasDao.getAllAliases().first()
        )
    }
}

// Pattern Types
object PatternTypes {
    const val ACTIVE_HOURS = "active_hours"
    const val PREFERRED_APPS = "preferred_apps"
    const val COMMON_CONTACTS = "common_contacts"
    const val VOLUME_PREFERENCE = "volume_preference"
    const val BRIGHTNESS_PREFERENCE = "brightness_preference"
}
