package com.see.assistant.modules

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.*
import android.view.animation.*
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.animation.doOnEnd
import androidx.core.content.ContextCompat
import com.airbnb.lottie.LottieAnimationView
import com.see.assistant.R
import com.see.assistant.utils.Logger
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * UIOverlayManager - Floating assistant UI
 * 
 * Features:
 * - Floating orb/circle
 * - Glowing animation
 * - Listening waveform
 * - Drag to move
 * - Tap to activate
 * - Auto-hide
 */
class UIOverlayManager(private val context: Context) {
    
    private val TAG = "UIOverlayManager"
    
    // Window manager
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    
    // Views
    private var floatingView: View? = null
    private var orbView: ImageView? = null
    private var animationView: LottieAnimationView? = null
    private var statusText: TextView? = null
    
    // State
    private val _isShowing = MutableStateFlow(false)
    val isShowing: StateFlow<Boolean> = _isShowing
    
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening
    
    // Layout params
    private var layoutParams: WindowManager.LayoutParams? = null
    
    // Animation
    private var glowAnimator: ValueAnimator? = null
    private var pulseAnimator: ObjectAnimator? = null
    private var floatAnimator: ValueAnimator? = null
    
    // Position
    private var initialX = 0
    private var initialY = 100
    private var touchX = 0f
    private var touchY = 0f
    
    // Coroutine
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var hideJob: Job? = null
    
    // Callback
    var onOrbClick: (() -> Unit)? = null
    var onOrbLongClick: (() -> Unit)? = null
    
    companion object {
        const val AUTO_HIDE_DELAY = 5000L // 5 seconds
        const val ORB_SIZE = 120 // dp
    }
    
    init {
        createFloatingView()
    }
    
    // ==================== CREATE UI ====================
    
    private fun createFloatingView() {
        // Inflate layout
        val inflater = LayoutInflater.from(context)
        floatingView = inflater.inflate(R.layout.floating_orb, null)
        
        // Get views
        orbView = floatingView?.findViewById(R.id.orb_image)
        animationView = floatingView?.findViewById(R.id.animation_view)
        statusText = floatingView?.findViewById(R.id.status_text)
        
        // Setup orb appearance
        setupOrbAppearance()
        
        // Setup touch handling
        setupTouchHandling()
        
        // Setup layout params
        setupLayoutParams()
        
        Logger.d(TAG, "🎨 Floating view created")
    }
    
    private fun setupOrbAppearance() {
        // Create glowing orb drawable
        val drawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(ContextCompat.getColor(context, R.color.orb_primary))
            
            // Add glow effect
            val glowColor = ContextCompat.getColor(context, R.color.orb_glow)
            // Note: Glow effect would need custom implementation or library
        }
        
        orbView?.background = drawable
        
        // Start idle animation
        startIdleAnimation()
    }
    
    private fun setupTouchHandling() {
        floatingView?.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    touchX = event.rawX
                    touchY = event.rawY
                    initialX = layoutParams?.x ?: 0
                    initialY = layoutParams?.y ?: 100
                    
                    // Cancel auto-hide
                    hideJob?.cancel()
                    
                    // Scale down effect
                    view.animate()
                        .scaleX(0.9f)
                        .scaleY(0.9f)
                        .setDuration(100)
                        .start()
                    
                    true
                }
                
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (event.rawX - touchX).toInt()
                    val deltaY = (event.rawY - touchY).toInt()
                    
                    layoutParams?.x = initialX + deltaX
                    layoutParams?.y = initialY + deltaY
                    
                    try {
                        windowManager.updateViewLayout(floatingView, layoutParams)
                    } catch (e: Exception) {
                        Logger.e(TAG, "Error updating view position", e)
                    }
                    
                    true
                }
                
                MotionEvent.ACTION_UP -> {
                    // Scale up effect
                    view.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(100)
                        .start()
                    
                    // Check if it was a click or drag
                    val deltaX = kotlin.math.abs(event.rawX - touchX)
                    val deltaY = kotlin.math.abs(event.rawY - touchY)
                    
                    if (deltaX < 10 && deltaY < 10) {
                        // It was a click
                        onOrbClick?.invoke()
                    }
                    
                    // Snap to edge if close
                    snapToEdge()
                    
                    // Restart auto-hide
                    scheduleAutoHide()
                    
                    true
                }
                
                else -> false
            }
        }
        
        // Long click for settings
        floatingView?.setOnLongClickListener {
            onOrbLongClick?.invoke()
            true
        }
    }
    
    private fun setupLayoutParams() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        
        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 300
        }
    }
    
    // ==================== ANIMATIONS ====================
    
    private fun startIdleAnimation() {
        // Gentle floating animation
        floatAnimator = ValueAnimator.ofFloat(0f, 1f, 0f).apply {
            duration = 3000
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { animator ->
                val value = animator.animatedValue as Float
                val translationY = value * 10 // Float 10px up and down
                orbView?.translationY = translationY
            }
            start()
        }
        
        // Subtle pulse
        pulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
            orbView,
            android.animation.PropertyValuesHolder.ofFloat("scaleX", 1f, 1.05f, 1f),
            android.animation.PropertyValuesHolder.ofFloat("scaleY", 1f, 1.05f, 1f)
        ).apply {
            duration = 2000
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }
    
    fun startListeningAnimation() {
        _isListening.value = true
        
        // Stop idle animations
        floatAnimator?.pause()
        pulseAnimator?.pause()
        
        // Show Lottie animation
        animationView?.apply {
            visibility = View.VISIBLE
            setAnimation(R.raw.listening_waveform)
            playAnimation()
        }
        
        // Hide static orb
        orbView?.visibility = View.GONE
        
        // Show status
        statusText?.apply {
            text = "Listening..."
            visibility = View.VISIBLE
            alpha = 0f
            animate()
                .alpha(1f)
                .setDuration(200)
                .start()
        }
        
        // Expand size
        expandOrb()
        
        Logger.d(TAG, "🎤 Listening animation started")
    }
    
    fun stopListeningAnimation() {
        _isListening.value = false
        
        // Hide Lottie
        animationView?.apply {
            pauseAnimation()
            visibility = View.GONE
        }
        
        // Show static orb
        orbView?.visibility = View.VISIBLE
        
        // Hide status
        statusText?.animate()
            ?.alpha(0f)
            ?.setDuration(200)
            ?.withEndAction {
                statusText?.visibility = View.GONE
            }
            ?.start()
        
        // Resume idle animations
        floatAnimator?.resume()
        pulseAnimator?.resume()
        
        // Shrink size
        shrinkOrb()
        
        Logger.d(TAG, "🛑 Listening animation stopped")
    }
    
    fun showThinkingAnimation() {
        animationView?.apply {
            visibility = View.VISIBLE
            setAnimation(R.raw.thinking_animation)
            playAnimation()
        }
        
        statusText?.apply {
            text = "Thinking..."
            visibility = View.VISIBLE
        }
        
        orbView?.visibility = View.GONE
    }
    
    fun showSuccessAnimation() {
        // Brief success indicator
        orbView?.apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_check_circle)
            
            animate()
                .scaleX(1.2f)
                .scaleY(1.2f)
                .setDuration(200)
                .withEndAction {
                    animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(200)
                        .start()
                }
                .start()
        }
        
        // Reset after delay
        scope.launch {
            delay(1000)
            orbView?.setImageDrawable(null)
        }
    }
    
    private fun expandOrb() {
        val targetSize = (ORB_SIZE * 1.5).toInt()
        
        orbView?.animate()
            ?.scaleX(1.5f)
            ?.scaleY(1.5f)
            ?.setDuration(300)
            ?.setInterpolator(DecelerateInterpolator())
            ?.start()
    }
    
    private fun shrinkOrb() {
        orbView?.animate()
            ?.scaleX(1f)
            ?.scaleY(1f)
            ?.setDuration(300)
            ?.setInterpolator(DecelerateInterpolator())
            ?.start()
    }
    
    // ==================== SHOW/HIDE ====================
    
    fun show() {
        if (_isShowing.value) return
        
        try {
            floatingView?.let { view ->
                windowManager.addView(view, layoutParams)
                _isShowing.value = true
                
                // Entrance animation
                view.alpha = 0f
                view.scaleX = 0f
                view.scaleY = 0f
                
                view.animate()
                    .alpha(1f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(300)
                    .setInterpolator(OvershootInterpolator())
                    .start()
                
                scheduleAutoHide()
                Logger.d(TAG, "👁️ Floating UI shown")
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to show floating UI", e)
        }
    }
    
    fun hide() {
        if (!_isShowing.value) return
        
        floatingView?.animate()
            ?.alpha(0f)
            ?.scaleX(0f)
            ?.scaleY(0f)
            ?.setDuration(200)
            ?.withEndAction {
                try {
                    windowManager.removeView(floatingView)
                } catch (e: Exception) {
                    Logger.e(TAG, "Error removing view", e)
                }
                _isShowing.value = false
            }
            ?.start()
        
        hideJob?.cancel()
        Logger.d(TAG, "🙈 Floating UI hidden")
    }
    
    fun toggle() {
        if (_isShowing.value) {
            hide()
        } else {
            show()
        }
    }
    
    private fun scheduleAutoHide() {
        hideJob?.cancel()
        hideJob = scope.launch {
            delay(AUTO_HIDE_DELAY)
            hide()
        }
    }
    
    // ==================== POSITIONING ====================
    
    private fun snapToEdge() {
        val displayMetrics = context.resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        
        val currentX = layoutParams?.x ?: 0
        val centerX = currentX + (ORB_SIZE * context.resources.displayMetrics.density / 2).toInt()
        
        val targetX = if (centerX < screenWidth / 2) {
            20 // Snap to left
        } else {
            screenWidth - ORB_SIZE - 20 // Snap to right
        }
        
        // Animate to edge
        val animator = ValueAnimator.ofInt(currentX, targetX)
        animator.apply {
            duration = 300
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                layoutParams?.x = it.animatedValue as Int
                try {
                    windowManager.updateViewLayout(floatingView, layoutParams)
                } catch (e: Exception) {
                    // View might be removed
                }
            }
            start()
        }
    }
    
    fun moveTo(x: Int, y: Int) {
        layoutParams?.x = x
        layoutParams?.y = y
        try {
            windowManager.updateViewLayout(floatingView, layoutParams)
        } catch (e: Exception) {
            Logger.e(TAG, "Error moving view", e)
        }
    }
    
    // ==================== CLEANUP ====================
    
    fun destroy() {
        hide()
        scope.cancel()
        
        floatAnimator?.cancel()
        pulseAnimator?.cancel()
        glowAnimator?.cancel()
        
        Logger.d(TAG, "👋 UIOverlayManager destroyed")
    }
}

/**
 * Floating UI States
 */
enum class OrbState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    SUCCESS,
    ERROR
}
