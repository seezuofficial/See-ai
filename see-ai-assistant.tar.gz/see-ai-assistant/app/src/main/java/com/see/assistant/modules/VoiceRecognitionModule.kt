package com.see.assistant.modules

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Process
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.see.assistant.utils.Logger
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener as VoskRecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * VoiceRecognitionModule - Speech-to-Text (STT)
 * 
 * Features:
 * - Offline recognition using Vosk
 * - Online fallback using Google Speech API
 * - Hinglish language support
 * - Continuous listening mode
 */
class VoiceRecognitionModule(private val context: Context) {
    
    private val TAG = "VoiceRecognitionModule"
    
    // State
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening
    
    private val _recognizedText = MutableStateFlow("")
    val recognizedText: StateFlow<String> = _recognizedText
    
    // Recognizers
    private var voskModel: Model? = null
    private var voskRecognizer: Recognizer? = null
    private var voskService: SpeechService? = null
    private var googleSpeechRecognizer: SpeechRecognizer? = null
    
    // Audio recording for offline
    private var audioRecord: AudioRecord? = null
    private val isRecording = MutableStateFlow(false)
    
    // Coroutine scope
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // Settings
    private var preferredRecognizer = "auto" // auto, offline, online
    private var speechLanguage = "hi-IN" // Hindi-India for Hinglish
    private var offlineMode = false
    
    // Callbacks
    private var onResult: ((String) -> Unit)? = null
    private var onPartialResult: ((String) -> Unit)? = null
    private var onError: ((String) -> Unit)? = null
    
    companion object {
        const val VOSK_MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"
        const val MODEL_DIR = "vosk-model"
    }
    
    suspend fun initialize() {
        Logger.d(TAG, "🎤 Initializing VoiceRecognitionModule")
        
        // Load settings
        val settings = SEEApplication.getInstance().settingsManager
        preferredRecognizer = settings.getPreferredRecognizer().first()
        speechLanguage = settings.getSpeechLanguage().first()
        offlineMode = settings.isOfflineMode().first()
        
        // Initialize Vosk for offline recognition
        initializeVosk()
        
        // Initialize Google Speech Recognizer for online fallback
        initializeGoogleSpeech()
        
        Logger.d(TAG, "✅ VoiceRecognitionModule initialized")
    }
    
    private suspend fun initializeVosk() {
        withContext(Dispatchers.IO) {
            try {
                val modelPath = File(context.filesDir, MODEL_DIR)
                
                if (!modelPath.exists()) {
                    Logger.w(TAG, "Vosk model not found, will download on first use")
                    // Model will be downloaded when needed
                    return@withContext
                }
                
                voskModel = Model(modelPath.absolutePath)
                Logger.i(TAG, "🧠 Vosk model loaded")
                
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to load Vosk model", e)
            }
        }
    }
    
    private fun initializeGoogleSpeech() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            googleSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
            Logger.d(TAG, "Google Speech Recognizer initialized")
        } else {
            Logger.w(TAG, "Google Speech Recognizer not available")
        }
    }
    
    // ==================== PUBLIC METHODS ====================
    
    fun startListening(
        onResult: (String) -> Unit,
        onPartialResult: ((String) -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        this.onResult = onResult
        this.onPartialResult = onPartialResult
        this.onError = onError
        
        _recognizedText.value = ""
        
        // Decide which recognizer to use
        val useOffline = offlineMode || preferredRecognizer == "offline" || voskModel != null
        
        if (useOffline && voskModel != null) {
            startOfflineListening()
        } else if (!offlineMode && googleSpeechRecognizer != null) {
            startOnlineListening()
        } else {
            onError?.invoke("No speech recognizer available")
        }
    }
    
    fun stopListening() {
        _isListening.value = false
        isRecording.value = false
        
        // Stop Vosk
        voskService?.stop()
        voskService = null
        
        // Stop Google
        googleSpeechRecognizer?.stopListening()
        
        // Stop audio record
        try {
            audioRecord?.apply {
                stop()
                release()
            }
            audioRecord = null
        } catch (e: Exception) {
            Logger.e(TAG, "Error stopping audio", e)
        }
        
        Logger.d(TAG, "🛑 Speech recognition stopped")
    }
    
    // ==================== OFFLINE RECOGNITION (VOSK) ====================
    
    private fun startOfflineListening() {
        scope.launch {
            try {
                _isListening.value = true
                
                // Use Vosk SpeechService for better handling
                val recognizer = Recognizer(voskModel, 16000.0f)
                recognizer.setWords(true)
                
                voskService = SpeechService(recognizer, 16000.0f)
                voskService?.startListening(object : VoskRecognitionListener {
                    override fun onPartialResult(hypothesis: String?) {
                        hypothesis?.let { parsePartialResult(it) }
                    }
                    
                    override fun onResult(hypothesis: String?) {
                        hypothesis?.let { parseResult(it) }
                    }
                    
                    override fun onFinalResult(hypothesis: String?) {
                        hypothesis?.let { parseResult(it) }
                        stopListening()
                    }
                    
                    override fun onError(exception: Exception?) {
                        Logger.e(TAG, "Vosk error", exception)
                        onError?.invoke(exception?.message ?: "Recognition error")
                        // Fallback to online
                        if (!offlineMode) {
                            startOnlineListening()
                        }
                    }
                    
                    override fun onTimeout() {
                        Logger.d(TAG, "Vosk timeout")
                        stopListening()
                    }
                })
                
                Logger.d(TAG, "🎙️ Offline listening started (Vosk)")
                
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to start offline listening", e)
                // Fallback to online
                if (!offlineMode) {
                    startOnlineListening()
                } else {
                    onError?.invoke("Offline recognition failed")
                }
            }
        }
    }
    
    private fun parsePartialResult(json: String) {
        try {
            val obj = JSONObject(json)
            val partial = obj.optString("partial", "")
            if (partial.isNotEmpty()) {
                _recognizedText.value = partial
                onPartialResult?.invoke(partial)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Error parsing partial result", e)
        }
    }
    
    private fun parseResult(json: String) {
        try {
            val obj = JSONObject(json)
            val text = obj.optString("text", "")
            if (text.isNotEmpty()) {
                _recognizedText.value = text
                onResult?.invoke(text)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Error parsing result", e)
        }
    }
    
    // ==================== ONLINE RECOGNITION (GOOGLE) ====================
    
    private fun startOnlineListening() {
        scope.launch(Dispatchers.Main) {
            try {
                _isListening.value = true
                
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, speechLanguage)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                }
                
                googleSpeechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        Logger.d(TAG, "Ready for speech")
                    }
                    
                    override fun onBeginningOfSpeech() {
                        Logger.d(TAG, "Speech began")
                    }
                    
                    override fun onRmsChanged(rmsdB: Float) {
                        // Audio level changed
                    }
                    
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    
                    override fun onEndOfSpeech() {
                        Logger.d(TAG, "Speech ended")
                    }
                    
                    override fun onError(error: Int) {
                        val errorMsg = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "Audio error"
                            SpeechRecognizer.ERROR_CLIENT -> "Client error"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permissions needed"
                            SpeechRecognizer.ERROR_NETWORK -> "Network error"
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized"
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                            SpeechRecognizer.ERROR_SERVER -> "Server error"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timeout"
                            else -> "Unknown error"
                        }
                        Logger.e(TAG, "Recognition error: $errorMsg")
                        onError?.invoke(errorMsg)
                        _isListening.value = false
                    }
                    
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val text = matches[0]
                            _recognizedText.value = text
                            onResult?.invoke(text)
                        }
                        _isListening.value = false
                    }
                    
                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val text = matches[0]
                            _recognizedText.value = text
                            onPartialResult?.invoke(text)
                        }
                    }
                    
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                
                googleSpeechRecognizer?.startListening(intent)
                Logger.d(TAG, "🌐 Online listening started (Google)")
                
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to start online listening", e)
                onError?.invoke("Failed to start recognition")
                _isListening.value = false
            }
        }
    }
    
    // ==================== MODEL DOWNLOAD ====================
    
    suspend fun downloadVoskModel(): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                Logger.i(TAG, "📥 Downloading Vosk model...")
                
                val modelDir = File(context.filesDir, MODEL_DIR)
                modelDir.mkdirs()
                
                val url = URL(VOSK_MODEL_URL)
                val connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = 30000
                connection.readTimeout = 60000
                
                val zipFile = File(context.cacheDir, "vosk_model.zip")
                
                connection.inputStream.use { input ->
                    FileOutputStream(zipFile).use { output ->
                        input.copyTo(output)
                    }
                }
                
                // Extract ZIP
                extractZip(zipFile, modelDir)
                
                // Delete ZIP
                zipFile.delete()
                
                // Reload model
                voskModel = Model(modelDir.absolutePath)
                
                Logger.i(TAG, "✅ Vosk model downloaded and loaded")
                true
                
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to download Vosk model", e)
                false
            }
        }
    }
    
    private fun extractZip(zipFile: File, destDir: File) {
        // Use Java's ZipInputStream for extraction
        java.util.zip.ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry: java.util.zip.ZipEntry?
            while (zis.nextEntry.also { entry = it } != null) {
                entry?.let {
                    val newFile = File(destDir, it.name)
                    if (it.isDirectory) {
                        newFile.mkdirs()
                    } else {
                        newFile.parentFile?.mkdirs()
                        newFile.outputStream().use { output ->
                            zis.copyTo(output)
                        }
                    }
                }
            }
        }
    }
    
    // ==================== UTILITY ====================
    
    fun isOfflineAvailable(): Boolean {
        return voskModel != null
    }
    
    fun isOnlineAvailable(): Boolean {
        return googleSpeechRecognizer != null
    }
    
    fun setPreferredRecognizer(recognizer: String) {
        preferredRecognizer = recognizer
    }
    
    fun setLanguage(language: String) {
        speechLanguage = language
    }
    
    fun shutdown() {
        stopListening()
        scope.cancel()
        googleSpeechRecognizer?.destroy()
        voskModel = null
        Logger.d(TAG, "👋 VoiceRecognitionModule shutdown")
    }
}

/**
 * AudioPreprocessor - Audio preprocessing for better recognition
 */
class AudioPreprocessor {
    
    companion object {
        private const val SAMPLE_RATE = 16000
        private const val FRAME_SIZE = 400 // 25ms
        private const val FRAME_SHIFT = 160 // 10ms
    }
    
    fun preprocess(audioData: ShortArray): FloatArray {
        // Convert to float
        val floatData = FloatArray(audioData.size)
        for (i in audioData.indices) {
            floatData[i] = audioData[i] / 32768.0f
        }
        
        // Apply pre-emphasis
        val preEmphasis = 0.97f
        for (i in floatData.size - 1 downTo 1) {
            floatData[i] -= preEmphasis * floatData[i - 1]
        }
        
        // Apply Hamming window
        applyHammingWindow(floatData)
        
        return floatData
    }
    
    private fun applyHammingWindow(data: FloatArray) {
        for (i in data.indices) {
            val window = 0.54f - 0.46f * kotlin.math.cos(2 * Math.PI * i / (data.size - 1)).toFloat()
            data[i] *= window
        }
    }
    
    fun removeNoise(audioData: FloatArray, noiseProfile: FloatArray?): FloatArray {
        // Simple spectral subtraction
        if (noiseProfile == null) return audioData
        
        val result = FloatArray(audioData.size)
        for (i in audioData.indices) {
            result[i] = (audioData[i] - noiseProfile.getOrElse(i) { 0f }).coerceAtLeast(0f)
        }
        return result
    }
}
