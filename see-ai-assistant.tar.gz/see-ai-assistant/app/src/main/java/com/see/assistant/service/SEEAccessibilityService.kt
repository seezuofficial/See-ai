package com.see.assistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.see.assistant.utils.Logger

/**
 * SEEAccessibilityService - UI automation ke liye
 * 
 * Capabilities:
 * - Click UI elements
 * - Scroll screens
 * - Read screen content
 * - Perform gestures
 * - Fill forms
 */
class SEEAccessibilityService : AccessibilityService() {
    
    private val TAG = "SEEAccessibilityService"
    
    companion object {
        var instance: SEEAccessibilityService? = null
            private set
        
        fun isRunning(): Boolean = instance != null
    }
    
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Logger.i(TAG, "♿ Accessibility Service connected")
        
        // Configure service
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_CLICKED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100
        }
    }
    
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event?.let {
            when (it.eventType) {
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                    Logger.d(TAG, "Window changed: ${it.packageName}")
                }
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                    // Content changed
                }
                AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                    Logger.d(TAG, "View clicked: ${it.source}")
                }
            }
        }
    }
    
    override fun onInterrupt() {
        Logger.w(TAG, "Accessibility Service interrupted")
    }
    
    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        Logger.i(TAG, "👋 Accessibility Service disconnected")
        return super.onUnbind(intent)
    }
    
    // ==================== UI AUTOMATION METHODS ====================
    
    /**
     * Find a node by text content
     */
    fun findNodeByText(text: String): AccessibilityNodeInfo? {
        val rootNode = rootInActiveWindow ?: return null
        return findNodeRecursive(rootNode, text)
    }
    
    private fun findNodeRecursive(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        // Check current node
        if (node.text?.contains(text, ignoreCase = true) == true ||
            node.contentDescription?.contains(text, ignoreCase = true) == true) {
            return node
        }
        
        // Check children
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            val found = child?.let { findNodeRecursive(it, text) }
            if (found != null) return found
        }
        
        return null
    }
    
    /**
     * Find a node by view ID
     */
    fun findNodeById(viewId: String): AccessibilityNodeInfo? {
        val rootNode = rootInActiveWindow ?: return null
        return rootNode.findAccessibilityNodeInfosByViewId(viewId)?.firstOrNull()
    }
    
    /**
     * Click on a node
     */
    fun clickNode(node: AccessibilityNodeInfo?): Boolean {
        node ?: return false
        
        return if (node.isClickable) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } else {
            // Try clicking parent
            clickNode(node.parent)
        }
    }
    
    /**
     * Click on text
     */
    fun clickByText(text: String): Boolean {
        val node = findNodeByText(text)
        return clickNode(node)
    }
    
    /**
     * Long click on a node
     */
    fun longClickNode(node: AccessibilityNodeInfo?): Boolean {
        node ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
    }
    
    /**
     * Scroll down
     */
    fun scrollDown(): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        
        // Find scrollable node
        val scrollableNode = findScrollableNode(rootNode)
        return scrollableNode?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) ?: false
    }
    
    /**
     * Scroll up
     */
    fun scrollUp(): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        
        val scrollableNode = findScrollableNode(rootNode)
        return scrollableNode?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ?: false
    }
    
    private fun findScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            val found = child?.let { findScrollableNode(it) }
            if (found != null) return found
        }
        
        return null
    }
    
    /**
     * Type text into an input field
     */
    fun typeText(node: AccessibilityNodeInfo?, text: String): Boolean {
        node ?: return false
        
        // Focus the field
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        
        // Set text
        val arguments = Bundle()
        arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }
    
    /**
     * Get all clickable elements on screen
     */
    fun getClickableElements(): List<String> {
        val elements = mutableListOf<String>()
        val rootNode = rootInActiveWindow ?: return elements
        
        collectClickableElements(rootNode, elements)
        return elements
    }
    
    private fun collectClickableElements(node: AccessibilityNodeInfo, elements: MutableList<String>) {
        if (node.isClickable) {
            val text = node.text?.toString() ?: node.contentDescription?.toString() ?: "Unknown"
            elements.add(text)
        }
        
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectClickableElements(it, elements) }
        }
    }
    
    /**
     * Perform a gesture (swipe, etc.)
     */
    fun performGesture(startX: Float, startY: Float, endX: Float, endY: Float, duration: Long = 300): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        
        return dispatchGesture(gesture, null, null)
    }
    
    /**
     * Swipe left
     */
    fun swipeLeft(): Boolean {
        val displayMetrics = resources.displayMetrics
        val centerY = displayMetrics.heightPixels / 2f
        val startX = displayMetrics.widthPixels * 0.8f
        val endX = displayMetrics.widthPixels * 0.2f
        
        return performGesture(startX, centerY, endX, centerY)
    }
    
    /**
     * Swipe right
     */
    fun swipeRight(): Boolean {
        val displayMetrics = resources.displayMetrics
        val centerY = displayMetrics.heightPixels / 2f
        val startX = displayMetrics.widthPixels * 0.2f
        val endX = displayMetrics.widthPixels * 0.8f
        
        return performGesture(startX, centerY, endX, centerY)
    }
    
    /**
     * Go back
     */
    fun goBack(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }
    
    /**
     * Go home
     */
    fun goHome(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }
    
    /**
     * Open recent apps
     */
    fun openRecents(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_RECENTS)
    }
    
    /**
     * Take screenshot (Android 9+)
     */
    fun takeScreenshot(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        } else {
            false
        }
    }
    
    /**
     * Get current app package name
     */
    fun getCurrentApp(): String? {
        return rootInActiveWindow?.packageName?.toString()
    }
    
    /**
     * Read screen text
     */
    fun readScreenText(): String {
        val rootNode = rootInActiveWindow ?: return ""
        val textBuilder = StringBuilder()
        collectText(rootNode, textBuilder)
        return textBuilder.toString()
    }
    
    private fun collectText(node: AccessibilityNodeInfo, builder: StringBuilder) {
        node.text?.let { builder.append(it).append(" ") }
        node.contentDescription?.let { builder.append(it).append(" ") }
        
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectText(it, builder) }
        }
    }
}
