package com.see.assistant.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.see.assistant.*
import com.see.assistant.modules.WakeWordModule
import com.see.assistant.ui.MainActivity
import com.see.assistant.utils.Logger
import kotlinx.coroutines.*

/**
 * WakeWordService - Dedicated service for wake word detection
 * 
 * Lightweight service that only listens for wake words
 * and notifies the main service when detected.
 */
class WakeWordService : Service() {
    
    private val TAG = "WakeWordService"
    
    private val binder = LocalBinder()
    private lateinit var wakeWordModule: WakeWordModule
    
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    
    var onWakeWordDetected: (() -> Unit)? = null
    
    inner class LocalBinder : Binder() {
        fun getService(): WakeWordService = this@WakeWordService
    }
    
    override fun onCreate() {
        super.onCreate()
        Logger.d(TAG, "👂 WakeWordService created")
        wakeWordModule = SEEApplication.getInstance().wakeWordModule
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Logger.d(TAG, "▶️ WakeWordService started")
        
        startForeground(NOTIFICATION_ID, createNotification())
        
        wakeWordModule.setWakeWordCallback {
            onWakeWordDetected?.invoke()
        }
        
        wakeWordModule.startListening()
        
        return START_STICKY
    }
    
    override fun onBind(intent: Intent): IBinder = binder
    
    override fun onDestroy() {
        super.onDestroy()
        Logger.d(TAG, "👋 WakeWordService destroyed")
        wakeWordModule.stopListening()
        serviceScope.cancel()
    }
    
    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, CHANNEL_SERVICE)
            .setContentTitle("SEE Wake Word")
            .setContentText("Say 'Hey SEE' to activate")
            .setSmallIcon(R.drawable.ic_mic)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }
    
    companion object {
        const val NOTIFICATION_ID = 1002
    }
}
