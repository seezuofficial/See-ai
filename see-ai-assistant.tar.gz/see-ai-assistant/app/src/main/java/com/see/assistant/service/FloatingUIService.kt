package com.see.assistant.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.see.assistant.*
import com.see.assistant.modules.UIOverlayManager
import com.see.assistant.ui.MainActivity
import com.see.assistant.utils.Logger
import kotlinx.coroutines.*

/**
 * FloatingUIService - Manages the floating assistant UI
 * 
 * This service keeps the floating orb visible even when
 * the main app is not in foreground.
 */
class FloatingUIService : Service() {
    
    private val TAG = "FloatingUIService"
    
    private val binder = LocalBinder()
    private lateinit var uiOverlayManager: UIOverlayManager
    
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    
    inner class LocalBinder : Binder() {
        fun getService(): FloatingUIService = this@FloatingUIService
    }
    
    override fun onCreate() {
        super.onCreate()
        Logger.d(TAG, "🎨 FloatingUIService created")
        uiOverlayManager = SEEApplication.getInstance().uiOverlayManager
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Logger.d(TAG, "▶️ FloatingUIService started")
        
        startForeground(NOTIFICATION_ID, createNotification())
        
        // Show the floating UI
        uiOverlayManager.show()
        
        return START_STICKY
    }
    
    override fun onBind(intent: Intent): IBinder = binder
    
    override fun onDestroy() {
        super.onDestroy()
        Logger.d(TAG, "👋 FloatingUIService destroyed")
        uiOverlayManager.hide()
        serviceScope.cancel()
    }
    
    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, CHANNEL_SERVICE)
            .setContentTitle("SEE Floating UI")
            .setContentText("Tap the orb to activate")
            .setSmallIcon(R.drawable.ic_assistant)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .addAction(
                R.drawable.ic_close,
                "Hide",
                PendingIntent.getService(
                    this,
                    0,
                    Intent(this, FloatingUIService::class.java).apply {
                        action = ACTION_HIDE
                    },
                    PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()
    }
    
    companion object {
        const val NOTIFICATION_ID = 1003
        const val ACTION_HIDE = "com.see.assistant.HIDE_FLOATING_UI"
        
        fun startService(context: android.content.Context) {
            val intent = Intent(context, FloatingUIService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
        
        fun stopService(context: android.content.Context) {
            context.stopService(Intent(context, FloatingUIService::class.java))
        }
    }
}
