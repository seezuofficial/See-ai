package com.see.assistant.utils

import android.util.Log
import com.see.assistant.BuildConfig

/**
 * Centralized logging utility for SEE
 * Debug builds mein verbose logging, release mein minimal
 */
object Logger {
    
    private const val GLOBAL_TAG = "SEE"
    private var isDebugMode = BuildConfig.DEBUG
    
    // Enable/disable logging
    fun setDebugMode(enabled: Boolean) {
        isDebugMode = enabled
    }
    
    @JvmStatic
    fun v(tag: String, message: String) {
        if (isDebugMode) Log.v("$GLOBAL_TAG:$tag", message)
    }
    
    @JvmStatic
    fun d(tag: String, message: String) {
        if (isDebugMode) Log.d("$GLOBAL_TAG:$tag", message)
    }
    
    @JvmStatic
    fun i(tag: String, message: String) {
        Log.i("$GLOBAL_TAG:$tag", message)
    }
    
    @JvmStatic
    fun w(tag: String, message: String) {
        Log.w("$GLOBAL_TAG:$tag", message)
    }
    
    @JvmStatic
    fun w(tag: String, message: String, throwable: Throwable?) {
        Log.w("$GLOBAL_TAG:$tag", message, throwable)
    }
    
    @JvmStatic
    fun e(tag: String, message: String) {
        Log.e("$GLOBAL_TAG:$tag", message)
    }
    
    @JvmStatic
    fun e(tag: String, message: String, throwable: Throwable?) {
        Log.e("$GLOBAL_TAG:$tag", message, throwable)
    }
    
    // Special method for user-visible logs (can be shown in UI)
    fun userLog(action: String, detail: String) {
        val message = "👤 USER: $action - $detail"
        if (isDebugMode) Log.d("$GLOBAL_TAG:USER", message)
    }
}

/**
 * Extension functions for easy logging
 */
fun Any.logV(message: String) = Logger.v(this::class.java.simpleName, message)
fun Any.logD(message: String) = Logger.d(this::class.java.simpleName, message)
fun Any.logI(message: String) = Logger.i(this::class.java.simpleName, message)
fun Any.logW(message: String) = Logger.w(this::class.java.simpleName, message)
fun Any.logE(message: String) = Logger.e(this::class.java.simpleName, message)
fun Any.logE(message: String, throwable: Throwable?) = Logger.e(this::class.java.simpleName, message, throwable)
