package com.see.assistant

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.see.assistant.modules.*
import com.see.assistant.service.SEECoreService
import com.see.assistant.ui.SettingsActivity
import com.see.assistant.ui.theme.SEETheme
import com.see.assistant.utils.Logger
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * MainActivity - SEE Assistant ka main screen
 */
class MainActivity : ComponentActivity() {
    
    private val TAG = "MainActivity"
    
    // Service connection
    private var coreService: SEECoreService? = null
    private var serviceBound = false
    
    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as SEECoreService.LocalBinder
            coreService = binder.getService()
            serviceBound = true
            Logger.d(TAG, "Service connected")
        }
        
        override fun onServiceDisconnected(name: ComponentName?) {
            coreService = null
            serviceBound = false
            Logger.d(TAG, "Service disconnected")
        }
    }
    
    // Permission launcher
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (allGranted) {
            Logger.i(TAG, "All permissions granted")
            startAssistantService()
        } else {
            Toast.makeText(this, "Some permissions denied", Toast.LENGTH_LONG).show()
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        Logger.i(TAG, "🚀 MainActivity created")
        
        // Check and request permissions
        checkPermissions()
        
        setContent {
            SEETheme {
                MainScreen(
                    onActivateClick = { activateAssistant() },
                    onSettingsClick = { openSettings() },
                    onPermissionsClick = { checkPermissions() }
                )
            }
        }
    }
    
    override fun onStart() {
        super.onStart()
        // Bind to service
        Intent(this, SEECoreService::class.java).also { intent ->
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        }
    }
    
    override fun onStop() {
        super.onStop()
        if (serviceBound) {
            unbindService(serviceConnection)
            serviceBound = false
        }
    }
    
    private fun checkPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.CAMERA
        )
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        
        permissionLauncher.launch(permissions.toTypedArray())
        
        // Check overlay permission
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }
    
    private fun startAssistantService() {
        SEECoreService.startService(this)
    }
    
    private fun activateAssistant() {
        if (serviceBound) {
            coreService?.activateAssistant()
        } else {
            // Start service and activate
            SEECoreService.startService(this)
            Toast.makeText(this, "Starting SEE Assistant...", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    onActivateClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onPermissionsClick: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    // State
    var userName by remember { mutableStateOf("Seezuu") }
    var isListening by remember { mutableStateOf(false) }
    var lastCommand by remember { mutableStateOf("") }
    
    // Load user name
    LaunchedEffect(Unit) {
        val settings = SEEApplication.getInstance().settingsManager
        userName = settings.getUserName().first()
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SEE Assistant") },
                actions = {
                    IconButton(onClick = onSettingsClick) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
            .padding(padding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.surface
                        )
                    )
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Welcome Section
            WelcomeSection(userName = userName)
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Main Orb Button
            OrbButton(
                isListening = isListening,
                onClick = {
                    isListening = !isListening
                    onActivateClick()
                }
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Status Card
            StatusCard(lastCommand = lastCommand)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Quick Actions
            QuickActionsRow(
                onFlashlightClick = { 
                    val executor = SEEApplication.getInstance().actionExecutor
                    executor.toggleFlashlight()
                    lastCommand = "Flashlight toggled"
                },
                onWifiClick = {
                    val executor = SEEApplication.getInstance().actionExecutor
                    executor.toggleWifi()
                    lastCommand = "WiFi toggled"
                },
                onVolumeClick = {
                    val executor = SEEApplication.getInstance().actionExecutor
                    executor.volumeUp()
                    lastCommand = "Volume up"
                },
                onSettingsClick = onSettingsClick
            )
            
            Spacer(modifier = Modifier.weight(1f))
            
            // Bottom Info
            Text(
                text = "Say 'Hey SEE' anytime to activate",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun WelcomeSection(userName: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Hello, $userName! 👋",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "I'm SEE, your personal AI assistant",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun OrbButton(
    isListening: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(150.dp)
            .clip(CircleShape)
            .background(
                if (isListening) {
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF00E676),
                            Color(0xFF00C853)
                        )
                    )
                } else {
                    Brush.radialGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        // Pulsing animation effect
        if (isListening) {
            Box(
                modifier = Modifier
                    .size(180.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF00E676).copy(alpha = 0.3f))
            )
        }
        
        Icon(
            imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
            contentDescription = if (isListening) "Listening" else "Tap to speak",
            modifier = Modifier.size(64.dp),
            tint = Color.White
        )
    }
}

@Composable
fun StatusCard(lastCommand: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Last Command",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = lastCommand.ifEmpty { "No commands yet" },
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

@Composable
fun QuickActionsRow(
    onFlashlightClick: () -> Unit,
    onWifiClick: () -> Unit,
    onVolumeClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        QuickActionButton(
            icon = Icons.Default.FlashlightOn,
            label = "Flashlight",
            onClick = onFlashlightClick
        )
        
        QuickActionButton(
            icon = Icons.Default.Wifi,
            label = "WiFi",
            onClick = onWifiClick
        )
        
        QuickActionButton(
            icon = Icons.Default.VolumeUp,
            label = "Volume",
            onClick = onVolumeClick
        )
        
        QuickActionButton(
            icon = Icons.Default.Settings,
            label = "Settings",
            onClick = onSettingsClick
        )
    }
}

@Composable
fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall
        )
    }
}
