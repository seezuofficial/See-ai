package com.see.assistant.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.see.assistant.SEEApplication
import com.see.assistant.ui.theme.SEETheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * VoiceCommandActivity - Transparent activity for handling voice commands
 * 
 * This activity is shown when the assistant is activated via wake word
 * or other triggers. It provides visual feedback during voice recognition.
 */
class VoiceCommandActivity : ComponentActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Make activity transparent
        setTheme(android.R.style.Theme_Translucent_NoTitleBar)
        
        setContent {
            SEETheme {
                VoiceCommandScreen(
                    onDismiss = { finish() }
                )
            }
        }
        
        // Start voice recognition
        startVoiceRecognition()
    }
    
    private fun startVoiceRecognition() {
        val voiceRecognition = SEEApplication.getInstance().voiceRecognitionModule
        val commandProcessor = SEEApplication.getInstance().commandProcessor
        
        voiceRecognition.startListening(
            onResult = { text ->
                commandProcessor.processTextCommand(text)
                finish()
            },
            onPartialResult = { /* Update UI */ },
            onError = { error ->
                finish()
            }
        )
    }
}

@Composable
fun VoiceCommandScreen(onDismiss: () -> Unit) {
    var statusText by remember { mutableStateOf("Listening...") }
    var recognizedText by remember { mutableStateOf("") }
    
    val scope = rememberCoroutineScope()
    
    // Auto-dismiss after timeout
    LaunchedEffect(Unit) {
        delay(10000) // 10 seconds timeout
        onDismiss()
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.7f),
                        androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.9f)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Pulsing orb
            PulsingOrb()
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Status text
            Text(
                text = statusText,
                style = MaterialTheme.typography.headlineSmall,
                color = androidx.compose.ui.graphics.Color.White
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Recognized text
            if (recognizedText.isNotEmpty()) {
                Text(
                    text = recognizedText,
                    style = MaterialTheme.typography.bodyLarge,
                    color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f)
                )
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Cancel button
            TextButton(onClick = onDismiss) {
                Text(
                    text = "Cancel",
                    color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.6f)
                )
            }
        }
    }
}

@Composable
fun PulsingOrb() {
    var scale by remember { mutableStateOf(1f) }
    
    LaunchedEffect(Unit) {
        while (true) {
            scale = 1.2f
            delay(500)
            scale = 1f
            delay(500)
        }
    }
    
    Box(
        modifier = Modifier
            .size(120.dp)
            .background(
                color = androidx.compose.ui.graphics.Color(0xFF6200EE),
                shape = androidx.compose.foundation.shape.CircleShape
            )
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            },
        contentAlignment = Alignment.Center
    ) {
        // Inner glow
        Box(
            modifier = Modifier
                .size(80.dp)
                .background(
                    color = androidx.compose.ui.graphics.Color(0xFFBB86FC).copy(alpha = 0.5f),
                    shape = androidx.compose.foundation.shape.CircleShape
                )
        )
        
        // Mic icon
        androidx.compose.material3.Icon(
            imageVector = androidx.compose.material.icons.Icons.Default.Mic,
            contentDescription = "Listening",
            modifier = Modifier.size(48.dp),
            tint = androidx.compose.ui.graphics.Color.White
        )
    }
}
