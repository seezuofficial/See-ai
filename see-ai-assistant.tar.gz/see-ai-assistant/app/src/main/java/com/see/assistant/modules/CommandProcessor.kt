package com.see.assistant.modules

import android.content.Context
import com.see.assistant.utils.Logger
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * CommandProcessor - Voice commands ko process karta hai
 * 
 * Features:
 * - Offline command processing
 * - Online AI fallback
 * - Command pattern matching
 * - Hinglish command support
 * - Context-aware responses
 */
class CommandProcessor(
    private val context: Context,
    private val voiceRecognition: VoiceRecognitionModule,
    private val actionExecutor: ActionExecutor,
    private val textToSpeech: TextToSpeechModule
) {
    
    private val TAG = "CommandProcessor"
    
    // State
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing
    
    private val _currentCommand = MutableStateFlow("")
    val currentCommand: StateFlow<String> = _currentCommand
    
    // Coroutine scope
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // Memory manager
    private val memoryManager by lazy { SEEApplication.getInstance().memoryManager }
    private val settingsManager by lazy { SEEApplication.getInstance().settingsManager }
    
    // Command patterns (Hinglish + English)
    private val commandPatterns = mutableListOf<CommandPattern>()
    
    suspend fun initialize() {
        Logger.d(TAG, "🧩 Initializing CommandProcessor")
        initializeCommandPatterns()
        Logger.d(TAG, "✅ CommandProcessor initialized with ${commandPatterns.size} patterns")
    }
    
    private fun initializeCommandPatterns() {
        // Flashlight commands
        addPattern(CommandType.FLASHLIGHT_ON, 
            listOf("flashlight on", "torch on", "light on", 
                   "flashlight on karo", "torch on karo", "light on karo",
                   "flashlight jalao", "torch jalao", "roshni karo"))
        
        addPattern(CommandType.FLASHLIGHT_OFF, 
            listOf("flashlight off", "torch off", "light off",
                   "flashlight band karo", "torch band karo", "light band karo",
                   "flashlight bujhao", "torch bujhao"))
        
        addPattern(CommandType.FLASHLIGHT_TOGGLE, 
            listOf("flashlight", "torch", "light toggle"))
        
        // WiFi commands
        addPattern(CommandType.WIFI_ON, 
            listOf("wifi on", "wifi chalu karo", "wifi start karo",
                   "internet on", "net on", "wifi connect karo"))
        
        addPattern(CommandType.WIFI_OFF, 
            listOf("wifi off", "wifi band karo", "wifi stop karo",
                   "internet off", "net off", "wifi disconnect karo"))
        
        addPattern(CommandType.WIFI_TOGGLE, 
            listOf("wifi toggle", "wifi switch"))
        
        // Bluetooth commands
        addPattern(CommandType.BLUETOOTH_ON, 
            listOf("bluetooth on", "bluetooth chalu karo", "bluetooth start karo",
                   "bt on", "bluetooth connect karo"))
        
        addPattern(CommandType.BLUETOOTH_OFF, 
            listOf("bluetooth off", "bluetooth band karo", "bluetooth stop karo",
                   "bt off", "bluetooth disconnect karo"))
        
        // Volume commands
        addPattern(CommandType.VOLUME_UP, 
            listOf("volume up", "volume badhao", "awaz badhao",
                   "sound badhao", "louder", "zyada awaz"))
        
        addPattern(CommandType.VOLUME_DOWN, 
            listOf("volume down", "volume kam karo", "awaz kam karo",
                   "sound kam karo", "quieter", "kam awaz"))
        
        addPattern(CommandType.MUTE, 
            listOf("mute", "silent", "chup", "awaz band"))
        
        addPattern(CommandType.UNMUTE, 
            listOf("unmute", "sound on", "awaz on"))
        
        // Call commands
        addPattern(CommandType.CALL, 
            listOf("call", "phone karo", "dial karo", "baat karo"),
            extractData = true)
        
        // SMS commands
        addPattern(CommandType.SMS, 
            listOf("sms", "message bhejo", "text bhejo", "msg karo"),
            extractData = true)
        
        // Alarm commands
        addPattern(CommandType.ALARM, 
            listOf("alarm", "alarm lagao", "alarm set karo", "jagao"),
            extractData = true)
        
        addPattern(CommandType.TIMER, 
            listOf("timer", "timer lagao", "timer set karo", "countdown"),
            extractData = true)
        
        // Screen lock
        addPattern(CommandType.LOCK, 
            listOf("lock", "screen lock", "phone lock", "lock karo"))
        
        // Settings
        addPattern(CommandType.SETTINGS, 
            listOf("settings", "setting", "settings khol", "setting khol"),
            extractData = true)
        
        // Search
        addPattern(CommandType.SEARCH, 
            listOf("search", "google", "dhundo", "search karo"),
            extractData = true)
        
        // App opening
        addPattern(CommandType.OPEN_APP, 
            listOf("open", "khol", "start", "launch", "chalu karo"),
            extractData = true)
        
        // Vibrate
        addPattern(CommandType.VIBRATE, 
            listOf("vibrate", "vibration", "hilao"))
        
        // Greetings
        addPattern(CommandType.CUSTOM, 
            listOf("hello", "hi", "namaste", "salaam", "hey"),
            action = { respondToGreeting() })
        
        addPattern(CommandType.CUSTOM, 
            listOf("how are you", "kaise ho", "kya haal", "sab theek"),
            action = { respondToHowAreYou() })
        
        addPattern(CommandType.CUSTOM, 
            listOf("thank you", "thanks", "shukriya", "dhanyawad"),
            action = { respondToThanks() })
        
        // Pro mode
        addPattern(CommandType.CUSTOM,
            listOf("pro mode", "activate pro", "pro mode on"),
            action = { activateProMode() })
    }
    
    private fun addPattern(
        type: CommandType, 
        patterns: List<String>, 
        extractData: Boolean = false,
        action: (() -> Unit)? = null
    ) {
        commandPatterns.add(CommandPattern(type, patterns, extractData, action))
    }
    
    // ==================== COMMAND PROCESSING ====================
    
    fun processVoiceCommand() {
        if (_isProcessing.value) {
            Logger.w(TAG, "Already processing a command")
            return
        }
        
        _isProcessing.value = true
        
        // Show listening UI
        scope.launch {
            val tone = settingsManager.getTone().first()
            val listeningMsg = TTSResponses.getListeningPrompt(tone)
            textToSpeech.speak(listeningMsg)
        }
        
        // Start voice recognition
        voiceRecognition.startListening(
            onResult = { text ->
                handleRecognizedText(text)
            },
            onPartialResult = { partial ->
                _currentCommand.value = partial
            },
            onError = { error ->
                handleError(error)
            }
        )
    }
    
    fun processTextCommand(text: String) {
        scope.launch {
            _isProcessing.value = true
            _currentCommand.value = text
            handleRecognizedText(text)
        }
    }
    
    private fun handleRecognizedText(text: String) {
        Logger.d(TAG, "🎤 Recognized: $text")
        
        scope.launch {
            // Save to memory
            memoryManager.recordCommandUsage(text)
            
            // Check for custom shortcuts first
            val shortcut = memoryManager.getShortcut(text.lowercase())
            if (shortcut != null) {
                executeShortcut(shortcut)
                return@launch
            }
            
            // Match command pattern
            val command = matchCommand(text)
            
            if (command != null) {
                executeCommand(command, text)
            } else {
                // Unknown command - use AI or suggest
                handleUnknownCommand(text)
            }
            
            _isProcessing.value = false
        }
    }
    
    private fun matchCommand(text: String): Command? {
        val lowerText = text.lowercase()
        
        for (pattern in commandPatterns) {
            for (trigger in pattern.triggers) {
                when {
                    // Exact match
                    lowerText == trigger -> {
                        return createCommand(pattern, text, trigger)
                    }
                    // Contains match
                    lowerText.contains(trigger) -> {
                        return createCommand(pattern, text, trigger)
                    }
                    // Fuzzy match (simple implementation)
                    calculateSimilarity(lowerText, trigger) > 0.8 -> {
                        return createCommand(pattern, text, trigger)
                    }
                }
            }
        }
        
        return null
    }
    
    private fun createCommand(pattern: CommandPattern, fullText: String, matchedTrigger: String): Command {
        val data = if (pattern.extractData) {
            extractDataFromText(fullText, matchedTrigger)
        } else ""
        
        return Command(pattern.type, data)
    }
    
    private fun extractDataFromText(text: String, trigger: String): String {
        // Remove trigger words and clean up
        var data = text.replace(trigger, "", ignoreCase = true)
            .replace("please", "", ignoreCase = true)
            .replace("kripaya", "", ignoreCase = true)
            .replace("se", "", ignoreCase = true)
            .replace("ko", "", ignoreCase = true)
            .trim()
        
        // Remove extra spaces
        data = data.replace(Regex("\\s+"), " ")
        
        return data
    }
    
    private fun calculateSimilarity(s1: String, s2: String): Double {
        // Simple Levenshtein distance-based similarity
        val maxLength = maxOf(s1.length, s2.length)
        if (maxLength == 0) return 1.0
        
        val distance = levenshteinDistance(s1, s2)
        return 1.0 - distance.toDouble() / maxLength
    }
    
    private fun levenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j
        
        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                dp[i][j] = if (s1[i - 1] == s2[j - 1]) {
                    dp[i - 1][j - 1]
                } else {
                    minOf(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]) + 1
                }
            }
        }
        
        return dp[s1.length][s2.length]
    }
    
    // ==================== COMMAND EXECUTION ====================
    
    private suspend fun executeCommand(command: Command, originalText: String) {
        Logger.d(TAG, "⚡ Executing: ${command.type} with data: ${command.data}")
        
        // Check for custom action
        val pattern = commandPatterns.find { it.type == command.type && it.action != null }
        if (pattern?.action != null) {
            pattern.action.invoke()
            return
        }
        
        // Execute via ActionExecutor
        val success = withContext(Dispatchers.Main) {
            actionExecutor.executeCommand(command)
        }
        
        // Get response based on result
        val response = if (success) {
            settingsManager.getResponseForAction(command.type.name.lowercase())
        } else {
            settingsManager.getResponseForAction("error")
        }
        
        // Speak response
        textToSpeech.speak(response)
        
        // Save conversation
        memoryManager.saveConversation(
            userMessage = originalText,
            assistantResponse = response,
            commandType = command.type.name,
            wasSuccessful = success
        )
    }
    
    private suspend fun executeShortcut(shortcut: CustomShortcut) {
        Logger.d(TAG, "🔖 Executing shortcut: ${shortcut.triggerPhrase}")
        
        // Parse and execute shortcut action
        val command = Command(
            type = CommandType.valueOf(shortcut.action),
            data = shortcut.actionData ?: ""
        )
        executeCommand(command, shortcut.triggerPhrase)
    }
    
    // ==================== CUSTOM RESPONSES ====================
    
    private suspend fun respondToGreeting() {
        val userName = settingsManager.getUserName().first()
        val tone = settingsManager.getTone().first()
        val response = TTSResponses.getWelcomeMessage(userName, tone)
        textToSpeech.speak(response)
    }
    
    private suspend fun respondToHowAreYou() {
        val responses = listOf(
            "Main bilkul theek hoon! Aap kaise ho?",
            "System fully operational! 😎",
            "Main toh mast hoon, aap sunao!",
            "All systems green! Ready to help."
        )
        val tone = settingsManager.getTone().first()
        val response = when (tone) {
            Tones.FRIENDLY -> responses[2]
            Tones.FUNNY -> responses[1]
            Tones.PROFESSIONAL -> responses[3]
            else -> responses[0]
        }
        textToSpeech.speak(response)
    }
    
    private suspend fun respondToThanks() {
        val responses = listOf(
            "Koi baat nahi! 😊",
            "You're welcome!",
            "Mera farz tha!",
            "Always here to help!"
        )
        textToSpeech.speak(responses.random())
    }
    
    private suspend fun activateProMode() {
        settingsManager.setProMode(true)
        textToSpeech.speak("Pro mode activated! Advanced features enabled. ⚡")
    }
    
    // ==================== UNKNOWN COMMAND HANDLING ====================
    
    private suspend fun handleUnknownCommand(text: String) {
        Logger.d(TAG, "❓ Unknown command: $text")
        
        val proMode = settingsManager.isProMode().first()
        
        if (proMode) {
            // In pro mode, try online AI processing
            processWithOnlineAI(text)
        } else {
            // Standard mode - suggest similar commands
            val suggestions = getSimilarCommands(text)
            val response = if (suggestions.isNotEmpty()) {
                "Samajh nahi aaya. Kya aap kehna chahte ho: ${suggestions.joinToString(" ya ")}?"
            } else {
                settingsManager.getResponseForAction("error")
            }
            textToSpeech.speak(response)
        }
    }
    
    private suspend fun processWithOnlineAI(text: String) {
        // This would connect to an AI service
        // For now, provide a helpful response
        textToSpeech.speak("Pro mode mein hoon, lekin abhi online AI connect nahi hai. 'Hey SEE' bolo aur command do.")
    }
    
    private fun getSimilarCommands(text: String): List<String> {
        // Return similar sounding commands
        return commandPatterns
            .filter { pattern ->
                pattern.triggers.any { trigger ->
                    calculateSimilarity(text.lowercase(), trigger) > 0.5
                }
            }
            .take(3)
            .map { it.triggers.first() }
    }
    
    // ==================== ERROR HANDLING ====================
    
    private fun handleError(error: String) {
        Logger.e(TAG, "Recognition error: $error")
        
        scope.launch {
            val response = settingsManager.getResponseForAction("error")
            textToSpeech.speak(response)
            _isProcessing.value = false
        }
    }
    
    // ==================== UTILITY ====================
    
    fun stopProcessing() {
        voiceRecognition.stopListening()
        _isProcessing.value = false
        _currentCommand.value = ""
    }
    
    fun getAvailableCommands(): List<String> {
        return commandPatterns.flatMap { it.triggers }.distinct()
    }
}

// Command Pattern Data Class
data class CommandPattern(
    val type: CommandType,
    val triggers: List<String>,
    val extractData: Boolean = false,
    val action: (() -> Unit)? = null
)
