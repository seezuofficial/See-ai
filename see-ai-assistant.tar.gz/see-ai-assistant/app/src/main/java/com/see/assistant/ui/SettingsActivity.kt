package com.see.assistant.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
nimport androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.see.assistant.SEEApplication
import com.see.assistant.modules.*
import com.see.assistant.ui.theme.SEETheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * SettingsActivity - SEE Assistant ki settings
 */
class SettingsActivity : ComponentActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            SEETheme {
                SettingsScreen(onBackClick = { finish() })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBackClick: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val settingsManager = SEEApplication.getInstance().settingsManager
    
    // State
    var assistantName by remember { mutableStateOf("SEE") }
    var userName by remember { mutableStateOf("Seezuu") }
    var voiceStyle by remember { mutableStateOf(VoiceStyles.FEMALE) }
    var tone by remember { mutableStateOf(Tones.FRIENDLY) }
    var theme by remember { mutableStateOf(Themes.DARK) }
    var language by remember { mutableStateOf(Languages.HINGLISH) }
    var wakeWordEnabled by remember { mutableStateOf(true) }
    var offlineMode by remember { mutableStateOf(false) }
    var proMode by remember { mutableStateOf(false) }
    var floatingUI by remember { mutableStateOf(true) }
    var ttsSpeed by remember { mutableStateOf(1.0f) }
    
    // Load settings
    LaunchedEffect(Unit) {
        assistantName = settingsManager.getAssistantName().first()
        userName = settingsManager.getUserName().first()
        voiceStyle = settingsManager.getVoiceStyle().first()
        tone = settingsManager.getTone().first()
        theme = settingsManager.getTheme().first()
        language = settingsManager.getLanguage().first()
        wakeWordEnabled = settingsManager.isWakeWordEnabled().first()
        offlineMode = settingsManager.isOfflineMode().first()
        proMode = settingsManager.isProMode().first()
        floatingUI = settingsManager.isFloatingUIEnabled().first()
        ttsSpeed = settingsManager.getTtsSpeed().first()
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Personalization Section
            item {
                SettingsSectionTitle("Personalization")
            }
            
            item {
                OutlinedTextField(
                    value = userName,
                    onValueChange = { 
                        userName = it
                        scope.launch { settingsManager.setUserName(it) }
                    },
                    label = { Text("Your Name") },
                    leadingIcon = { Icon(Icons.Default.Person, null) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            
            item {
                OutlinedTextField(
                    value = assistantName,
                    onValueChange = { 
                        assistantName = it
                        scope.launch { settingsManager.setAssistantName(it) }
                    },
                    label = { Text("Assistant Name") },
                    leadingIcon = { Icon(Icons.Default.SmartToy, null) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            
            // Voice Section
            item {
                SettingsSectionTitle("Voice & Speech")
            }
            
            item {
                SettingsDropdown(
                    label = "Voice Style",
                    selected = voiceStyle,
                    options = listOf(VoiceStyles.MALE, VoiceStyles.FEMALE, VoiceStyles.ROBOTIC),
                    onSelect = { 
                        voiceStyle = it
                        scope.launch { settingsManager.setVoiceStyle(it) }
                    }
                )
            }
            
            item {
                SettingsDropdown(
                    label = "Personality/Tone",
                    selected = tone,
                    options = listOf(Tones.FRIENDLY, Tones.FUNNY, Tones.ROMANTIC, Tones.PROFESSIONAL),
                    onSelect = { 
                        tone = it
                        scope.launch { settingsManager.setTone(it) }
                    }
                )
            }
            
            item {
                SettingsDropdown(
                    label = "Language",
                    selected = language,
                    options = listOf(Languages.HINDI, Languages.ENGLISH, Languages.HINGLISH, Languages.JAPANESE),
                    onSelect = { 
                        language = it
                        scope.launch { settingsManager.setLanguage(it) }
                    }
                )
            }
            
            item {
                Column {
                    Text("Speech Speed: ${String.format("%.1f", ttsSpeed)}x")
                    Slider(
                        value = ttsSpeed,
                        onValueChange = { 
                            ttsSpeed = it
                            scope.launch { settingsManager.setTtsSpeed(it) }
                        },
                        valueRange = 0.5f..2.0f,
                        steps = 15
                    )
                }
            }
            
            // Features Section
            item {
                SettingsSectionTitle("Features")
            }
            
            item {
                SettingsSwitch(
                    title = "Wake Word Detection",
                    subtitle = "Say 'Hey SEE' to activate",
                    checked = wakeWordEnabled,
                    onCheckedChange = { 
                        wakeWordEnabled = it
                        scope.launch { settingsManager.setWakeWordEnabled(it) }
                    }
                )
            }
            
            item {
                SettingsSwitch(
                    title = "Floating UI",
                    subtitle = "Show floating orb on screen",
                    checked = floatingUI,
                    onCheckedChange = { 
                        floatingUI = it
                        scope.launch { settingsManager.setFloatingUIEnabled(it) }
                    }
                )
            }
            
            item {
                SettingsSwitch(
                    title = "Offline Mode",
                    subtitle = "Use only offline recognition",
                    checked = offlineMode,
                    onCheckedChange = { 
                        offlineMode = it
                        scope.launch { settingsManager.setOfflineMode(it) }
                    }
                )
            }
            
            item {
                SettingsSwitch(
                    title = "Pro Mode",
                    subtitle = "Advanced features and faster processing",
                    checked = proMode,
                    onCheckedChange = { 
                        proMode = it
                        scope.launch { settingsManager.setProMode(it) }
                    }
                )
            }
            
            // Appearance Section
            item {
                SettingsSectionTitle("Appearance")
            }
            
            item {
                SettingsDropdown(
                    label = "Theme",
                    selected = theme,
                    options = listOf(Themes.DARK, Themes.LIGHT, Themes.NEON),
                    onSelect = { 
                        theme = it
                        scope.launch { settingsManager.setTheme(it) }
                    }
                )
            }
            
            // About Section
            item {
                SettingsSectionTitle("About")
            }
            
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = "SEE AI Assistant",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Version 1.0.0",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Your personal AI assistant powered by advanced voice recognition and automation.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsSectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
    )
}

@Composable
fun SettingsSwitch(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.bodyLarge)
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDropdown(
    label: String,
    selected: String,
    options: List<String>,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = selected.replaceFirstChar { it.uppercase() },
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
        )
        
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option.replaceFirstChar { it.uppercase() }) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}
