package com.see.assistant.modules

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.see.assistant.utils.Logger
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.*

/**
 * TextToSpeechModule - TTS for assistant responses
 * 
 * Features:
 * - Android TTS Engine
 * - Hinglish language support
 * - Multiple voice styles
 * - Speed and pitch control
 * - Online TTS fallback (Google Translate TTS)
 */
class TextToSpeechModule(private val context: Context) {
    
    private val TAG = "TextToSpeechModule"
    
    // State
    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking
    
    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized
    
    // TTS Engine
    private var textToSpeech: TextToSpeech? = null
    private var mediaPlayer: MediaPlayer? = null
    
    // Audio Manager for focus
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null
    
    // Settings
    private var voiceStyle = "female"
    private var language = "hinglish"
    private var speed = 1.0f
    private var pitch = 1.0f
    
    // Coroutine
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    
    // Queue for sequential speaking
    private val speechQueue = mutableListOf<String>()
    private var isProcessingQueue = false
    
    companion object {
        const val UTTERANCE_ID = "SEE_TTS"
        const val GOOGLE_TTS_URL = "https://translate.google.com/translate_tts"
    }
    
    suspend fun initialize() {
        Logger.d(TAG, "🔊 Initializing TextToSpeechModule")
        
        // Load settings
        val settings = SEEApplication.getInstance().settingsManager
        voiceStyle = settings.getVoiceStyle().first()
        language = settings.getLanguage().first()
        speed = settings.getTtsSpeed().first()
        pitch = settings.getTtsPitch().first()
        
        // Initialize TTS
        initTTS()
        
        Logger.d(TAG, "✅ TextToSpeechModule initialized")
    }
    
    private suspend fun initTTS() {
        return suspendCancellableCoroutine { continuation ->
            textToSpeech = TextToSpeech(context) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    configureTTS()
                    _isInitialized.value = true
                    Logger.i(TAG, "TTS initialized successfully")
                    continuation.resume(Unit) {}
                } else {
                    Logger.e(TAG, "TTS initialization failed: $status")
                    continuation.resume(Unit) {}
                }
            }
        }
    }
    
    private fun configureTTS() {
        textToSpeech?.apply {
            // Set language based on preference
            val locale = when (language) {
                "hindi" -> Locale("hi", "IN")
                "english" -> Locale.ENGLISH
                "hinglish" -> Locale("hi", "IN") // Use Hindi locale for Hinglish
                "japanese" -> Locale.JAPANESE
                else -> Locale("hi", "IN")
            }
            
            val result = setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Logger.w(TAG, "Language not fully supported, using default")
            }
            
            // Set speech rate and pitch
            setSpeechRate(speed)
            setPitch(pitch)
            
            // Set voice style if available
            setVoiceStyle()
            
            // Set utterance listener
            setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }
                
                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    processNextInQueue()
                }
                
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    Logger.e(TAG, "TTS error for utterance: $utteranceId")
                    processNextInQueue()
                }
            })
        }
    }
    
    private fun setVoiceStyle() {
        textToSpeech?.let { tts ->
            val voices = tts.voices
            
            val preferredVoice = when (voiceStyle) {
                VoiceStyles.FEMALE -> voices?.find { 
                    it.name.contains("female", ignoreCase = true) || 
                    it.name.contains("woman", ignoreCase = true) ||
                    it.name.contains("hi-IN", ignoreCase = true)
                }
                VoiceStyles.MALE -> voices?.find { 
                    it.name.contains("male", ignoreCase = true) || 
                    it.name.contains("man", ignoreCase = true)
                }
                VoiceStyles.ROBOTIC -> voices?.find { 
                    it.name.contains("robot", ignoreCase = true) ||
                    it.quality == Voice.QUALITY_VERY_LOW
                }
                else -> null
            }
            
            preferredVoice?.let {
                try {
                    tts.voice = it
                    Logger.d(TAG, "Voice set to: ${it.name}")
                } catch (e: Exception) {
                    Logger.e(TAG, "Failed to set voice", e)
                }
            }
        }
    }
    
    // ==================== SPEAK METHODS ====================
    
    fun speak(text: String, queue: Boolean = false) {
        if (queue) {
            speechQueue.add(text)
            if (!isProcessingQueue) {
                processNextInQueue()
            }
        } else {
            speechQueue.clear()
            speakInternal(text)
        }
    }
    
    fun speakHinglish(text: String) {
        // Convert Hinglish text to better pronunciation
        val processedText = processHinglishText(text)
        speak(processedText)
    }
    
    private fun speakInternal(text: String) {
        if (!_isInitialized.value) {
            Logger.w(TAG, "TTS not initialized, queuing: $text")
            speechQueue.add(text)
            return
        }
        
        // Request audio focus
        if (!requestAudioFocus()) {
            Logger.w(TAG, "Could not get audio focus")
        }
        
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, UTTERANCE_ID)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, params, UTTERANCE_ID)
        } else {
            @Suppress("DEPRECATION")
            val map = HashMap<String, String>()
            map[TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID] = UTTERANCE_ID
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, map)
        }
        
        Logger.d(TAG, "🗣️ Speaking: $text")
    }
    
    private fun processNextInQueue() {
        if (speechQueue.isEmpty()) {
            isProcessingQueue = false
            abandonAudioFocus()
            return
        }
        
        isProcessingQueue = true
        val nextText = speechQueue.removeAt(0)
        speakInternal(nextText)
    }
    
    // ==================== HINGLISH PROCESSING ====================
    
    private fun processHinglishText(text: String): String {
        // Convert common Hinglish words to better pronunciation
        val replacements = mapOf(
            "kya" to "क्या",
            "hai" to "है",
            "nahi" to "नहीं",
            "kar" to "कर",
            "diya" to "दिया",
            "ho" to "हो",
            "gaya" to "गया",
            "main" to "मैं",
            "hoon" to "हूँ",
            "aap" to "आप",
            "tum" to "तुम",
            "kaise" to "कैसे",
            "theek" to "ठीक",
            "bhai" to "भाई",
            "yaar" to "यार",
            "arre" to "अरे",
            "bas" to "बस",
            "chal" to "चल",
            "dekh" to "देख",
            "suno" to "सुनो",
            "batao" to "बताओ",
            "samajh" to "समझ",
            "zara" to "ज़रा",
            "thoda" to "थोड़ा",
            "bahut" to "बहुत",
            "acha" to "अच्छा",
            "bura" to "बुरा",
            "naya" to "नया",
            "purana" to "पुराना",
            "jaldi" to "जल्दी",
            "dheere" to "धीरे",
            "yahan" to "यहाँ",
            "wahan" to "वहाँ",
            "kidhar" to "किधर",
            "kaun" to "कौन",
            "kab" to "कब",
            "kyun" to "क्यों"
        )
        
        var processed = text
        
        // Replace words
        replacements.forEach { (hinglish, hindi) ->
            processed = processed.replace(Regex("\\b$hinglish\\b", RegexOption.IGNORE_CASE), hindi)
        }
        
        return processed
    }
    
    // ==================== ONLINE TTS FALLBACK ====================
    
    fun speakOnline(text: String, language: String = "hi") {
        scope.launch {
            try {
                val audioFile = downloadTTS(text, language)
                if (audioFile != null) {
                    playAudioFile(audioFile)
                } else {
                    // Fallback to offline TTS
                    speak(text)
                }
            } catch (e: Exception) {
                Logger.e(TAG, "Online TTS failed", e)
                speak(text)
            }
        }
    }
    
    private suspend fun downloadTTS(text: String, language: String): File? {
        return withContext(Dispatchers.IO) {
            try {
                val encodedText = URLEncoder.encode(text, "UTF-8")
                val url = "$GOOGLE_TTS_URL?ie=UTF-8&q=$encodedText&tl=$language&client=tw-ob"
                
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.setRequestProperty("User-Agent", "Mozilla/5.0")
                
                val audioFile = File(context.cacheDir, "tts_${System.currentTimeMillis()}.mp3")
                
                connection.inputStream.use { input ->
                    FileOutputStream(audioFile).use { output ->
                        input.copyTo(output)
                    }
                }
                
                audioFile
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to download TTS", e)
                null
            }
        }
    }
    
    private fun playAudioFile(file: File) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(file.absolutePath)
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            setOnPreparedListener { start() }
            setOnCompletionListener {
                _isSpeaking.value = false
                file.delete()
            }
            setOnErrorListener { _, _, _ ->
                _isSpeaking.value = false
                true
            }
            prepareAsync()
        }
    }
    
    // ==================== AUDIO FOCUS ====================
    
    private fun requestAudioFocus(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setOnAudioFocusChangeListener { }
                .build()
            audioManager.requestAudioFocus(audioFocusRequest!!) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                null,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
    }
    
    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let {
                audioManager.abandonAudioFocusRequest(it)
            }
        } else {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus(null)
        }
    }
    
    // ==================== CONTROL METHODS ====================
    
    fun stop() {
        textToSpeech?.stop()
        mediaPlayer?.stop()
        _isSpeaking.value = false
        speechQueue.clear()
        isProcessingQueue = false
    }
    
    fun setSpeed(newSpeed: Float) {
        speed = newSpeed.coerceIn(0.5f, 2.0f)
        textToSpeech?.setSpeechRate(speed)
    }
    
    fun setPitch(newPitch: Float) {
        pitch = newPitch.coerceIn(0.5f, 2.0f)
        textToSpeech?.setPitch(pitch)
    }
    
    // ==================== SHUTDOWN ====================
    
    fun shutdown() {
        stop()
        textToSpeech?.shutdown()
        mediaPlayer?.release()
        scope.cancel()
        Logger.d(TAG, "👋 TextToSpeechModule shutdown")
    }
}

// Predefined responses
object TTSResponses {
    fun getWelcomeMessage(userName: String, tone: String): String {
        return when (tone) {
            Tones.FRIENDLY -> "Hello $userName! Main SEE hoon, aapka personal assistant. Kya help chahiye?"
            Tones.FUNNY -> "Namaste $userName! Main aa gaya hoon, ab tension mat lo! 😎"
            Tones.ROMANTIC -> "Hey $userName, tumhari yaad aa rahi thi... kya karoon tumhare liye? 💕"
            Tones.PROFESSIONAL -> "Greetings $userName. SEE Assistant at your service. How may I assist you?"
            else -> "Hello $userName! Main ready hoon."
        }
    }
    
    fun getListeningPrompt(tone: String): String {
        return when (tone) {
            Tones.FRIENDLY -> "Haan bolo, sun raha hoon..."
            Tones.FUNNY -> "Bolo bolo, kaan laga ke sun raha hoon!"
            Tones.ROMANTIC -> "Haan jaan, bolo..."
            Tones.PROFESSIONAL -> "I'm listening."
            else -> "Boliye..."
        }
    }
    
    fun getErrorMessage(tone: String): String {
        return when (tone) {
            Tones.FRIENDLY -> "Arre kuch problem ho gayi, dobara try karo please."
            Tones.FUNNY -> "Oops! System ne thoda drama kiya, phir se bolo! 😅"
            Tones.ROMANTIC -> "Sorry jaan, samajh nahi paya, ek baar phir bolo na..."
            Tones.PROFESSIONAL -> "I apologize, I didn't understand. Please repeat."
            else -> "Samajh nahi aaya, dobara bolo."
        }
    }
}
