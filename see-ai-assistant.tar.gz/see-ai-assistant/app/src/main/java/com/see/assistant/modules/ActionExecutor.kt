package com.see.assistant.modules

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.os.Vibrator
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.widget.Toast
import com.see.assistant.receiver.SEEDeviceAdminReceiver
import com.see.assistant.receiver.AlarmReceiver
import com.see.assistant.utils.Logger
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.util.*

/**
 * ActionExecutor - Phone automation ke liye
 * 
 * Capabilities:
 * - Open apps
 * - Control flashlight
 * - Toggle WiFi/Bluetooth
 * - Set alarms/reminders
 * - Call/SMS
 * - Volume control
 * - Screen lock/unlock
 * - System settings
 */
class ActionExecutor(private val context: Context) {
    
    private val TAG = "ActionExecutor"
    
    // System services
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val devicePolicyManager = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    private val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    
    // State
    private var flashlightOn = false
    private var cameraId: String? = null
    
    // Coroutine
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // Callback
    var onActionComplete: ((String, Boolean) -> Unit)? = null
    
    suspend fun initialize() {
        Logger.d(TAG, "⚡ Initializing ActionExecutor")
        
        // Get camera ID for flashlight
        try {
            cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to get camera ID", e)
        }
        
        Logger.d(TAG, "✅ ActionExecutor initialized")
    }
    
    // ==================== APP CONTROL ====================
    
    fun openApp(packageName: String): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                notifySuccess("app_open", "App opened: $packageName")
                true
            } else {
                notifyError("app_open", "App not found: $packageName")
                false
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to open app: $packageName", e)
            notifyError("app_open", e.message ?: "Unknown error")
            false
        }
    }
    
    fun openAppByName(appName: String): Boolean {
        val packageName = getPackageNameForApp(appName)
        return if (packageName != null) {
            openApp(packageName)
        } else {
            // Try search
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val apps = context.packageManager.queryIntentActivities(intent, 0)
            val matchedApp = apps.find { 
                it.loadLabel(context.packageManager).toString().contains(appName, ignoreCase = true) 
            }
            
            if (matchedApp != null) {
                openApp(matchedApp.activityInfo.packageName)
            } else {
                notifyError("app_open", "App not found: $appName")
                false
            }
        }
    }
    
    private fun getPackageNameForApp(appName: String): String? {
        val appMap = mapOf(
            "whatsapp" to "com.whatsapp",
            "facebook" to "com.facebook.katana",
            "instagram" to "com.instagram.android",
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "camera" to "com.android.camera",
            "gallery" to "com.android.gallery3d",
            "settings" to "com.android.settings",
            "phone" to "com.android.dialer",
            "messages" to "com.android.messaging",
            "calendar" to "com.android.calendar",
            "clock" to "com.android.deskclock",
            "calculator" to "com.android.calculator2",
            "music" to "com.android.music",
            "play store" to "com.android.vending",
            "spotify" to "com.spotify.music",
            "netflix" to "com.netflix.mediaclient"
        )
        
        return appMap[appName.lowercase()]
    }
    
    // ==================== FLASHLIGHT ====================
    
    fun toggleFlashlight(): Boolean {
        return if (flashlightOn) {
            turnOffFlashlight()
        } else {
            turnOnFlashlight()
        }
    }
    
    fun turnOnFlashlight(): Boolean {
        return try {
            cameraId?.let { id ->
                cameraManager.setTorchMode(id, true)
                flashlightOn = true
                notifySuccess("flashlight_on", "Flashlight turned on")
                true
            } ?: run {
                notifyError("flashlight", "Flashlight not available")
                false
            }
        } catch (e: CameraAccessException) {
            Logger.e(TAG, "Failed to turn on flashlight", e)
            notifyError("flashlight", e.message ?: "Camera access error")
            false
        }
    }
    
    fun turnOffFlashlight(): Boolean {
        return try {
            cameraId?.let { id ->
                cameraManager.setTorchMode(id, false)
                flashlightOn = false
                notifySuccess("flashlight_off", "Flashlight turned off")
                true
            } ?: run {
                false
            }
        } catch (e: CameraAccessException) {
            Logger.e(TAG, "Failed to turn off flashlight", e)
            notifyError("flashlight", e.message ?: "Camera access error")
            false
        }
    }
    
    // ==================== WIFI ====================
    
    fun toggleWifi(): Boolean {
        return if (wifiManager.isWifiEnabled) {
            turnOffWifi()
        } else {
            turnOnWifi()
        }
    }
    
    fun turnOnWifi(): Boolean {
        return try {
            val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // For Android 10+, use settings panel
                val intent = Intent(Settings.Panel.ACTION_WIFI)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else {
                @Suppress("DEPRECATION")
                wifiManager.isWifiEnabled = true
            }
            notifySuccess("wifi_on", "WiFi turned on")
            result
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to turn on WiFi", e)
            notifyError("wifi", e.message ?: "WiFi error")
            false
        }
    }
    
    fun turnOffWifi(): Boolean {
        return try {
            val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val intent = Intent(Settings.Panel.ACTION_WIFI)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else {
                @Suppress("DEPRECATION")
                wifiManager.isWifiEnabled = false
            }
            notifySuccess("wifi_off", "WiFi turned off")
            result
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to turn off WiFi", e)
            notifyError("wifi", e.message ?: "WiFi error")
            false
        }
    }
    
    // ==================== BLUETOOTH ====================
    
    fun toggleBluetooth(): Boolean {
        val bluetoothAdapter = bluetoothManager.adapter
        return if (bluetoothAdapter?.isEnabled == true) {
            turnOffBluetooth()
        } else {
            turnOnBluetooth()
        }
    }
    
    fun turnOnBluetooth(): Boolean {
        return try {
            val bluetoothAdapter = bluetoothManager.adapter
            val result = bluetoothAdapter?.enable() ?: false
            if (result) {
                notifySuccess("bluetooth_on", "Bluetooth turned on")
            }
            result
        } catch (e: SecurityException) {
            Logger.e(TAG, "Bluetooth permission denied", e)
            // Open settings
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        }
    }
    
    fun turnOffBluetooth(): Boolean {
        return try {
            val bluetoothAdapter = bluetoothManager.adapter
            val result = bluetoothAdapter?.disable() ?: false
            if (result) {
                notifySuccess("bluetooth_off", "Bluetooth turned off")
            }
            result
        } catch (e: SecurityException) {
            Logger.e(TAG, "Bluetooth permission denied", e)
            true
        }
    }
    
    // ==================== VOLUME CONTROL ====================
    
    fun volumeUp() {
        audioManager.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        notifySuccess("volume_up", "Volume increased")
    }
    
    fun volumeDown() {
        audioManager.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        notifySuccess("volume_down", "Volume decreased")
    }
    
    fun setVolume(level: Int, stream: Int = AudioManager.STREAM_MUSIC) {
        val maxVolume = audioManager.getStreamMaxVolume(stream)
        val targetVolume = (level * maxVolume / 100).coerceIn(0, maxVolume)
        audioManager.setStreamVolume(stream, targetVolume, AudioManager.FLAG_SHOW_UI)
        notifySuccess("volume_set", "Volume set to $level%")
    }
    
    fun mute() {
        audioManager.adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
        notifySuccess("mute", "Muted")
    }
    
    fun unmute() {
        audioManager.adjustVolume(AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
        notifySuccess("unmute", "Unmuted")
    }
    
    // ==================== BRIGHTNESS ====================
    
    fun setBrightness(level: Int) {
        try {
            val brightness = level.coerceIn(0, 255)
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                brightness
            )
            notifySuccess("brightness", "Brightness set to $level")
        } catch (e: SecurityException) {
            // Open brightness settings
            val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }
    
    // ==================== CALL & SMS ====================
    
    fun makeCall(phoneNumber: String) {
        try {
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$phoneNumber")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            notifySuccess("call", "Calling $phoneNumber")
        } catch (e: SecurityException) {
            // Fallback to dialer
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$phoneNumber")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            notifySuccess("call", "Opening dialer for $phoneNumber")
        }
    }
    
    fun makeCallByName(contactName: String) {
        scope.launch {
            val phoneNumber = findContactNumber(contactName)
            if (phoneNumber != null) {
                makeCall(phoneNumber)
            } else {
                notifyError("call", "Contact not found: $contactName")
            }
        }
    }
    
    fun sendSMS(phoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            val parts = smsManager.divideMessage(message)
            smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null)
            notifySuccess("sms", "SMS sent to $phoneNumber")
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to send SMS", e)
            // Open SMS app
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$phoneNumber")
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            notifySuccess("sms", "Opening SMS app")
        }
    }
    
    fun sendSMSToContact(contactName: String, message: String) {
        scope.launch {
            val phoneNumber = findContactNumber(contactName)
            if (phoneNumber != null) {
                sendSMS(phoneNumber, message)
            } else {
                notifyError("sms", "Contact not found: $contactName")
            }
        }
    }
    
    private suspend fun findContactNumber(contactName: String): String? {
        return withContext(Dispatchers.IO) {
            try {
                // First check aliases
                val memoryManager = SEEApplication.getInstance().memoryManager
                val alias = memoryManager.getContactByAlias(contactName)
                if (alias?.phoneNumber != null) {
                    return@withContext alias.phoneNumber
                }
                
                // Search contacts
                val cursor = context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(
                        ContactsContract.CommonDataKinds.Phone.NUMBER,
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                    ),
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                    arrayOf("%$contactName%"),
                    null
                )
                
                cursor?.use {
                    if (it.moveToFirst()) {
                        val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        return@withContext it.getString(numberIndex)
                    }
                }
                null
            } catch (e: SecurityException) {
                Logger.e(TAG, "Contact permission denied", e)
                null
            }
        }
    }
    
    // ==================== ALARM & REMINDER ====================
    
    fun setAlarm(hour: Int, minute: Int, message: String = "Alarm") {
        try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            notifySuccess("alarm", "Alarm set for $hour:$minute")
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to set alarm", e)
            notifyError("alarm", "Could not set alarm")
        }
    }
    
    fun setTimer(seconds: Int, message: String = "Timer") {
        try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            notifySuccess("timer", "Timer set for $seconds seconds")
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to set timer", e)
            notifyError("timer", "Could not set timer")
        }
    }
    
    fun setReminder(message: String, timeInMillis: Long) {
        try {
            val intent = Intent(context, AlarmReceiver::class.java).apply {
                putExtra("message", message)
            }
            
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                timeInMillis.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        timeInMillis,
                        pendingIntent
                    )
                }
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    timeInMillis,
                    pendingIntent
                )
            }
            
            notifySuccess("reminder", "Reminder set: $message")
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to set reminder", e)
            notifyError("reminder", "Could not set reminder")
        }
    }
    
    // ==================== SCREEN CONTROL ====================
    
    fun turnOnScreen() {
        try {
            val wakeLock = powerManager.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "SEE:ScreenOn"
            )
            wakeLock.acquire(10 * 1000)
            wakeLock.release()
            notifySuccess("screen_on", "Screen turned on")
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to turn on screen", e)
        }
    }
    
    fun lockScreen() {
        try {
            val componentName = ComponentName(context, SEEDeviceAdminReceiver::class.java)
            if (devicePolicyManager.isAdminActive(componentName)) {
                devicePolicyManager.lockNow()
                notifySuccess("lock", "Screen locked")
            } else {
                // Request admin permission
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName)
                    putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "SEE needs device admin permission to lock the screen")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to lock screen", e)
            notifyError("lock", "Could not lock screen")
        }
    }
    
    // ==================== SYSTEM SETTINGS ====================
    
    fun openSettings(settingType: String = "main") {
        val intent = when (settingType.lowercase()) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "apps" -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
            "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "security" -> Intent(Settings.ACTION_SECURITY_SETTINGS)
            "storage" -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            "date" -> Intent(Settings.ACTION_DATE_SETTINGS)
            "language" -> Intent(Settings.ACTION_LOCALE_SETTINGS)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "developer" -> Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            "about" -> Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        notifySuccess("settings", "Opening $settingType settings")
    }
    
    // ==================== UTILITY ====================
    
    fun vibrate(duration: Long = 200) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(android.os.VibrationEffect.createOneShot(duration, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(duration)
        }
    }
    
    fun takeScreenshot() {
        // Use MediaProjection API (requires additional setup)
        // For now, show toast
        showToast("Screenshot feature requires additional permissions")
    }
    
    fun searchWeb(query: String) {
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        notifySuccess("search", "Searching: $query")
    }
    
    fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
    
    // ==================== NOTIFICATIONS ====================
    
    fun readNotifications() {
        // This requires NotificationListenerService
        // Implementation in NotificationService
        notifySuccess("notifications", "Reading notifications...")
    }
    
    // ==================== CALLBACKS ====================
    
    private fun notifySuccess(action: String, message: String) {
        Logger.d(TAG, "✅ $action: $message")
        onActionComplete?.invoke(action, true)
    }
    
    private fun notifyError(action: String, message: String) {
        Logger.e(TAG, "❌ $action: $message")
        onActionComplete?.invoke(action, false)
    }
    
    // ==================== EXECUTE COMMAND ====================
    
    fun executeCommand(command: Command): Boolean {
        return when (command.type) {
            CommandType.OPEN_APP -> openAppByName(command.data)
            CommandType.FLASHLIGHT_ON -> turnOnFlashlight()
            CommandType.FLASHLIGHT_OFF -> turnOffFlashlight()
            CommandType.FLASHLIGHT_TOGGLE -> toggleFlashlight()
            CommandType.WIFI_ON -> turnOnWifi()
            CommandType.WIFI_OFF -> turnOffWifi()
            CommandType.WIFI_TOGGLE -> toggleWifi()
            CommandType.BLUETOOTH_ON -> turnOnBluetooth()
            CommandType.BLUETOOTH_OFF -> turnOffBluetooth()
            CommandType.BLUETOOTH_TOGGLE -> toggleBluetooth()
            CommandType.VOLUME_UP -> { volumeUp(); true }
            CommandType.VOLUME_DOWN -> { volumeDown(); true }
            CommandType.MUTE -> { mute(); true }
            CommandType.UNMUTE -> { unmute(); true }
            CommandType.CALL -> { makeCallByName(command.data); true }
            CommandType.SMS -> {
                val parts = command.data.split("|", limit = 2)
                if (parts.size == 2) {
                    sendSMSToContact(parts[0], parts[1])
                } else {
                    notifyError("sms", "Invalid format")
                }
                true
            }
            CommandType.ALARM -> {
                val parts = command.data.split(":")
                if (parts.size >= 2) {
                    setAlarm(parts[0].toInt(), parts[1].toInt())
                }
                true
            }
            CommandType.TIMER -> {
                setTimer(command.data.toInt())
                true
            }
            CommandType.LOCK -> { lockScreen(); true }
            CommandType.SETTINGS -> { openSettings(command.data); true }
            CommandType.SEARCH -> { searchWeb(command.data); true }
            CommandType.VIBRATE -> { vibrate(); true }
            CommandType.CUSTOM -> {
                // Handle custom commands
                true
            }
            else -> {
                notifyError("unknown", "Unknown command type")
                false
            }
        }
    }
}

// Command Types
enum class CommandType {
    OPEN_APP,
    FLASHLIGHT_ON, FLASHLIGHT_OFF, FLASHLIGHT_TOGGLE,
    WIFI_ON, WIFI_OFF, WIFI_TOGGLE,
    BLUETOOTH_ON, BLUETOOTH_OFF, BLUETOOTH_TOGGLE,
    VOLUME_UP, VOLUME_DOWN, MUTE, UNMUTE,
    BRIGHTNESS_UP, BRIGHTNESS_DOWN,
    CALL, SMS,
    ALARM, TIMER, REMINDER,
    LOCK, UNLOCK,
    SETTINGS, SEARCH,
    VIBRATE, SCREENSHOT,
    NOTIFICATIONS,
    CUSTOM, UNKNOWN
}

data class Command(
    val type: CommandType,
    val data: String = "",
    val confidence: Float = 1.0f
)
