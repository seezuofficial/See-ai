package com.see.assistant.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Dark Theme Colors
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val OnDarkPrimary = Color(0xFFFFFFFF)
val OnDarkSecondary = Color(0xFFCCCCCC)
val OnDarkBackground = Color(0xFFFFFFFF)
val OnDarkSurface = Color(0xFFFFFFFF)

// Light Theme Colors
val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF5F5F5)
val OnLightPrimary = Color(0xFF000000)
val OnLightSecondary = Color(0xFF333333)
val OnLightBackground = Color(0xFF000000)
val OnLightSurface = Color(0xFF000000)

// Neon Colors (Pro Mode)
val NeonGreen = Color(0xFF00FF88)
val NeonBlue = Color(0xFF00CCFF)
val NeonPink = Color(0xFFFF00AA)
val NeonYellow = Color(0xFFFFEE00)
val NeonPurple = Color(0xFFAA00FF)

// Orb Colors
val OrbPrimary = Color(0xFF6200EE)
val OrbGlow = Color(0xFFBB86FC)
val OrbActive = Color(0xFF00E676)
val OrbListening = Color(0xFF00B0FF)
